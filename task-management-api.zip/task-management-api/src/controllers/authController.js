// src/controllers/authController.js
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { authValidation, validate } = require('../utils/validation');
const { sendEmail } = require('../services/emailService');

const generateToken = (userId) => {
  return jwt.sign({ id: userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d'
  });
};

const authController = {
  register: [
    validate(authValidation.register),
    async (req, res) => {
      try {
        const { username, email, password, roles } = req.body;

        // Check if user already exists
        const existingUser = await User.findOne({
          $or: [{ email }, { username }]
        });

        if (existingUser) {
          return res.status(400).json({
            success: false,
            message: 'User with this email or username already exists'
          });
        }

        // Create user
        const user = new User({
          username,
          email,
          password,
          roles: roles || ['user']
        });

        await user.save();

        // Send confirmation email (optional)
        try {
          await sendEmail({
            to: email,
            subject: 'Welcome to Task Management System',
            html: `<h1>Welcome ${username}!</h1><p>Your account has been successfully created.</p>`
          });
        } catch (emailError) {
          console.error('Failed to send welcome email:', emailError);
        }

        // Generate token
        const token = generateToken(user._id);

        res.status(201).json({
          success: true,
          message: 'User registered successfully',
          data: {
            user: {
              id: user._id,
              username: user.username,
              email: user.email,
              roles: user.roles
            },
            token
          }
        });
      } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({
          success: false,
          message: 'Internal server error'
        });
      }
    }
  ],

  login: [
    validate(authValidation.login),
    async (req, res) => {
      try {
        const { email, password } = req.body;

        // Find user
        const user = await User.findOne({ email, isActive: true });
        if (!user) {
          return res.status(401).json({
            success: false,
            message: 'Invalid credentials'
          });
        }

        // Check password
        const isPasswordValid = await user.comparePassword(password);
        if (!isPasswordValid) {
          return res.status(401).json({
            success: false,
            message: 'Invalid credentials'
          });
        }

        // Update last login
        user.lastLogin = new Date();
        await user.save();

        // Generate token
        const token = generateToken(user._id);

        res.json({
          success: true,
          message: 'Login successful',
          data: {
            user: {
              id: user._id,
              username: user.username,
              email: user.email,
              roles: user.roles
            },
            token
          }
        });
      } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({
          success: false,
          message: 'Internal server error'
        });
      }
    }
  ],

  logout: async (req, res) => {
    try {
      // In a production environment, you might want to maintain a blacklist of tokens
      // For now, we'll just return success as JWT is stateless
      res.json({
        success: true,
        message: 'Logged out successfully'
      });
    } catch (error) {
      console.error('Logout error:', error);
      res.status(500).json({
        success: false,
        message: 'Internal server error'
      });
    }
  },

  getProfile: async (req, res) => {
    try {
      const user = await User.findById(req.user.id).select('-password');
      
      res.json({
        success: true,
        data: { user }
      });
    } catch (error) {
      console.error('Get profile error:', error);
      res.status(500).json({
        success: false,
        message: 'Internal server error'
      });
    }
  }
};

module.exports = authController;