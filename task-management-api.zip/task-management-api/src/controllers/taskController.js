// src/controllers/taskController.js
const Task = require('../models/Task');
const User = require('../models/User');
const { taskValidation, validate } = require('../utils/validation');
const { emitTaskUpdate } = require('../services/socketService');

const taskController = {
  createTask: [
    validate(taskValidation.create),
    async (req, res) => {
      try {
        const taskData = {
          ...req.body,
          createdBy: req.user.id
        };

        // Check if assigned user exists
        const assignedUser = await User.findById(taskData.assignedTo);
        if (!assignedUser) {
          return res.status(404).json({
            success: false,
            message: 'Assigned user not found'
          });
        }

        // Check permissions for assignment
        if (!req.user.roles.includes('admin') && !req.user.roles.includes('manager')) {
          // Regular users can only assign tasks to themselves
          if (taskData.assignedTo !== req.user.id) {
            return res.status(403).json({
              success: false,
              message: 'You can only assign tasks to yourself'
            });
          }
        }

        const task = new Task(taskData);
        await task.save();

        // Populate for response
        await task.populate('assignedTo', 'username email');
        await task.populate('createdBy', 'username email');

        // Emit real-time update
        emitTaskUpdate('task_created', task);

        res.status(201).json({
          success: true,
          message: 'Task created successfully',
          data: { task }
        });
      } catch (error) {
        console.error('Create task error:', error);
        res.status(500).json({
          success: false,
          message: 'Internal server error'
        });
      }
    }
  ],

  getTasks: async (req, res) => {
    try {
      const {
        page = 1,
        limit = 10,
        status,
        priority,
        assignedTo,
        search,
        sortBy = 'dueDate',
        sortOrder = 'asc'
      } = req.query;

      // Build filter
      const filter = {};

      // Regular users can only see their own tasks
      if (req.user.roles.includes('user') && !req.user.roles.includes('manager') && !req.user.roles.includes('admin')) {
        filter.$or = [
          { assignedTo: req.user.id },
          { createdBy: req.user.id }
        ];
      } else if (req.user.roles.includes('manager') && !req.user.roles.includes('admin')) {
        // Managers can see tasks assigned to their team members
        const teamMembers = await User.find({ team: req.user.team }).select('_id');
        const teamMemberIds = teamMembers.map(member => member._id);
        
        filter.$or = [
          { assignedTo: { $in: teamMemberIds } },
          { createdBy: req.user.id }
        ];
      }
      // Admins can see all tasks (no additional filter)

      // Apply additional filters
      if (status) filter.status = status;
      if (priority) filter.priority = priority;
      if (assignedTo) filter.assignedTo = assignedTo;
      if (search) {
        filter.$or = [
          { title: { $regex: search, $options: 'i' } },
          { description: { $regex: search, $options: 'i' } },
          { tags: { $in: [new RegExp(search, 'i')] } }
        ];
      }

      // Build sort
      const sort = {};
      sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

      const tasks = await Task.find(filter)
        .populate('assignedTo', 'username email')
        .populate('createdBy', 'username email')
        .sort(sort)
        .limit(limit * 1)
        .skip((page - 1) * limit);

      const total = await Task.countDocuments(filter);

      res.json({
        success: true,
        data: {
          tasks,
          pagination: {
            current: page,
            pages: Math.ceil(total / limit),
            total
          }
        }
      });
    } catch (error) {
      console.error('Get tasks error:', error);
      res.status(500).json({
        success: false,
        message: 'Internal server error'
      });
    }
  },

  getTask: async (req, res) => {
    try {
      const task = await Task.findById(req.params.id)
        .populate('assignedTo', 'username email')
        .populate('createdBy', 'username email');

      if (!task) {
        return res.status(404).json({
          success: false,
          message: 'Task not found'
        });
      }

      // Check permissions
      if (!req.user.roles.includes('admin')) {
        if (req.user.roles.includes('manager')) {
          // Managers can only access tasks of their team members
          const assignedUser = await User.findById(task.assignedTo);
          if (assignedUser.team !== req.user.team && task.createdBy.toString() !== req.user.id) {
            return res.status(403).json({
              success: false,
              message: 'Access denied'
            });
          }
        } else {
          // Regular users can only access their own tasks
          if (task.assignedTo._id.toString() !== req.user.id && task.createdBy._id.toString() !== req.user.id) {
            return res.status(403).json({
              success: false,
              message: 'Access denied'
            });
          }
        }
      }

      res.json({
        success: true,
        data: { task }
      });
    } catch (error) {
      console.error('Get task error:', error);
      res.status(500).json({
        success: false,
        message: 'Internal server error'
      });
    }
  },

  updateTask: [
    validate(taskValidation.update),
    async (req, res) => {
      try {
        let task = await Task.findById(req.params.id);

        if (!task) {
          return res.status(404).json({
            success: false,
            message: 'Task not found'
          });
        }

        // Check permissions
        if (!req.user.roles.includes('admin')) {
          if (req.user.roles.includes('manager')) {
            // Managers can only update tasks of their team members
            const assignedUser = await User.findById(task.assignedTo);
            if (assignedUser.team !== req.user.team && task.createdBy.toString() !== req.user.id) {
              return res.status(403).json({
                success: false,
                message: 'Access denied'
              });
            }
          } else {
            // Regular users can only update their own assigned tasks
            if (task.assignedTo.toString() !== req.user.id && task.createdBy.toString() !== req.user.id) {
              return res.status(403).json({
                success: false,
                message: 'Access denied'
              });
            }
          }
        }

        // Check assignment permissions
        if (req.body.assignedTo && !req.user.roles.includes('admin') && !req.user.roles.includes('manager')) {
          // Regular users cannot reassign tasks
          if (req.body.assignedTo !== req.user.id) {
            return res.status(403).json({
              success: false,
              message: 'You cannot reassign tasks to other users'
            });
          }
        }

        task = await Task.findByIdAndUpdate(
          req.params.id,
          req.body,
          { new: true, runValidators: true }
        )
        .populate('assignedTo', 'username email')
        .populate('createdBy', 'username email');

        // Emit real-time update
        emitTaskUpdate('task_updated', task);

        res.json({
          success: true,
          message: 'Task updated successfully',
          data: { task }
        });
      } catch (error) {
        console.error('Update task error:', error);
        res.status(500).json({
          success: false,
          message: 'Internal server error'
        });
      }
    }
  ],

  deleteTask: async (req, res) => {
    try {
      const task = await Task.findById(req.params.id);

      if (!task) {
        return res.status(404).json({
          success: false,
          message: 'Task not found'
        });
      }

      // Check permissions
      if (!req.user.roles.includes('admin') && task.createdBy.toString() !== req.user.id) {
        return res.status(403).json({
          success: false,
          message: 'You can only delete tasks you created'
        });
      }

      await Task.findByIdAndDelete(req.params.id);

      // Emit real-time update
      emitTaskUpdate('task_deleted', { id: req.params.id });

      res.json({
        success: true,
        message: 'Task deleted successfully'
      });
    } catch (error) {
      console.error('Delete task error:', error);
      res.status(500).json({
        success: false,
        message: 'Internal server error'
      });
    }
  }
};

module.exports = taskController;