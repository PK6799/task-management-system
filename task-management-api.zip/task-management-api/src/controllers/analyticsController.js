// src/controllers/analyticsController.js
const Task = require('../models/Task');
const User = require('../models/User');

const analyticsController = {
  getTaskStats: async (req, res) => {
    try {
      const { startDate, endDate, team } = req.query;
      
      let dateFilter = {};
      if (startDate || endDate) {
        dateFilter.createdAt = {};
        if (startDate) dateFilter.createdAt.$gte = new Date(startDate);
        if (endDate) dateFilter.createdAt.$lte = new Date(endDate);
      }

      // Build user filter based on role
      let userFilter = {};
      if (req.user.roles.includes('manager') && !req.user.roles.includes('admin')) {
        const teamMembers = await User.find({ team: req.user.team }).select('_id');
        userFilter.assignedTo = { $in: teamMembers.map(member => member._id) };
      } else if (req.user.roles.includes('user') && !req.user.roles.includes('manager') && !req.user.roles.includes('admin')) {
        userFilter.assignedTo = req.user.id;
      }

      const filter = { ...dateFilter, ...userFilter };

      const stats = await Task.aggregate([
        { $match: filter },
        {
          $group: {
            _id: '$status',
            count: { $sum: 1 },
            totalEstimatedHours: { $sum: '$estimatedHours' },
            totalActualHours: { $sum: '$actualHours' }
          }
        }
      ]);

      const totalTasks = await Task.countDocuments(filter);
      const overdueTasks = await Task.countDocuments({
        ...filter,
        dueDate: { $lt: new Date() },
        status: { $ne: 'completed' }
      });

      const result = {
        total: totalTasks,
        overdue: overdueTasks,
        byStatus: stats.reduce((acc, stat) => {
          acc[stat._id] = {
            count: stat.count,
            estimatedHours: stat.totalEstimatedHours || 0,
            actualHours: stat.totalActualHours || 0
          };
          return acc;
        }, {})
      };

      res.json({
        success: true,
        data: result
      });
    } catch (error) {
      console.error('Get task stats error:', error);
      res.status(500).json({
        success: false,
        message: 'Internal server error'
      });
    }
  },

  getUserStats: async (req, res) => {
    try {
      if (!req.user.roles.includes('admin') && !req.user.roles.includes('manager')) {
        return res.status(403).json({
          success: false,
          message: 'Insufficient permissions'
        });
      }

      let userFilter = {};
      if (req.user.roles.includes('manager') && !req.user.roles.includes('admin')) {
        userFilter.team = req.user.team;
      }

      const userStats = await User.aggregate([
        { $match: userFilter },
        {
          $lookup: {
            from: 'tasks',
            localField: '_id',
            foreignField: 'assignedTo',
            as: 'tasks'
          }
        },
        {
          $project: {
            username: 1,
            email: 1,
            roles: 1,
            team: 1,
            totalTasks: { $size: '$tasks' },
            completedTasks: {
              $size: {
                $filter: {
                  input: '$tasks',
                  as: 'task',
                  cond: { $eq: ['$$task.status', 'completed'] }
                }
              }
            },
            pendingTasks: {
              $size: {
                $filter: {
                  input: '$tasks',
                  as: 'task',
                  cond: { $ne: ['$$task.status', 'completed'] }
                }
              }
            }
          }
        }
      ]);

      res.json({
        success: true,
        data: userStats
      });
    } catch (error) {
      console.error('Get user stats error:', error);
      res.status(500).json({
        success: false,
        message: 'Internal server error'
      });
    }
  }
};

module.exports = analyticsController;