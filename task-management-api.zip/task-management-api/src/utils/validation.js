// src/utils/validation.js
const Joi = require('joi');

const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

const authValidation = {
  register: Joi.object({
    username: Joi.string().alphanum().min(3).max(30).required(),
    email: Joi.string().email().required(),
    password: Joi.string().pattern(passwordRegex).required().messages({
      'string.pattern.base': 'Password must contain at least 8 characters, one uppercase, one lowercase, one number and one special character'
    }),
    roles: Joi.array().items(Joi.string().valid('user', 'manager', 'admin'))
  }),

  login: Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().required()
  })
};

const taskValidation = {
  create: Joi.object({
    title: Joi.string().max(100).required(),
    description: Joi.string().max(1000).allow(''),
    dueDate: Joi.date().greater('now').required(),
    priority: Joi.string().valid('low', 'medium', 'high'),
    status: Joi.string().valid('pending', 'in-progress', 'completed', 'cancelled'),
    assignedTo: Joi.string().hex().length(24).required(),
    tags: Joi.array().items(Joi.string()),
    estimatedHours: Joi.number().min(0),
    actualHours: Joi.number().min(0)
  }),

  update: Joi.object({
    title: Joi.string().max(100),
    description: Joi.string().max(1000).allow(''),
    dueDate: Joi.date().greater('now'),
    priority: Joi.string().valid('low', 'medium', 'high'),
    status: Joi.string().valid('pending', 'in-progress', 'completed', 'cancelled'),
    assignedTo: Joi.string().hex().length(24),
    tags: Joi.array().items(Joi.string()),
    estimatedHours: Joi.number().min(0),
    actualHours: Joi.number().min(0)
  })
};

const validate = (schema) => {
  return (req, res, next) => {
    const { error } = schema.validate(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        message: error.details[0].message
      });
    }
    next();
  };
};

module.exports = {
  authValidation,
  taskValidation,
  validate
};