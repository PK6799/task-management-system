// src/routes/admin.js
const express = require('express');
const User = require('../models/User');
const Task = require('../models/Task');
const auth = require('../middleware/auth');
const rbac = require('../middleware/rbac');
const { generalLimiter } = require('../middleware/rateLimit');

const router = express.Router();

router.use(auth, rbac(['admin']), generalLimiter);

// User management endpoints
router.get('/users', async (req, res) => {
  try {
    const users = await User.find().select('-password');
    res.json({
      success: true,
      data: { users }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

router.put('/users/:id', async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    ).select('-password');

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }

    res.json({
      success: true,
      message: 'User updated successfully',
      data: { user }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

module.exports = router;