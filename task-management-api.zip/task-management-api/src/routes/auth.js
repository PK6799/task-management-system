// src/routes/auth.js
const express = require('express');
const authController = require('../controllers/authController');
const auth = require('../middleware/auth');
const { authLimiter, generalLimiter } = require('../middleware/rateLimit');

const router = express.Router();

router.post('/register', generalLimiter, authController.register);
router.post('/login', authLimiter, authController.login);
router.post('/logout', auth, authController.logout);
router.get('/profile', auth, authController.getProfile);

module.exports = router;