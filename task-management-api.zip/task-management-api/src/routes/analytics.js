// src/routes/analytics.js
const express = require('express');
const analyticsController = require('../controllers/analyticsController');
const auth = require('../middleware/auth');
const rbac = require('../middleware/rbac');
const { cache } = require('../middleware/cache');
const { generalLimiter } = require('../middleware/rateLimit');

const router = express.Router();

router.use(auth);

router.get('/tasks', generalLimiter, cache(600), analyticsController.getTaskStats);
router.get('/users', generalLimiter, rbac(['admin', 'manager']), cache(600), analyticsController.getUserStats);

module.exports = router;