// src/middleware/rateLimit.js
const rateLimit = require('express-rate-limit');
const { redisClient } = require('../config/redis');

const redisStore = {
  incr: async (key) => {
    const current = await redisClient.get(key);
    if (current === null) {
      await redisClient.setEx(key, 60, '1');
      return 1;
    }
    const newCount = parseInt(current) + 1;
    await redisClient.setEx(key, 60, newCount.toString());
    return newCount;
  }
};

const createRateLimiter = (windowMs, max, message) => {
  return rateLimit({
    windowMs,
    max,
    message: { success: false, message },
    store: redisStore
  });
};

// Different rate limits for different scenarios
const authLimiter = createRateLimiter(15 * 60 * 1000, 5, 'Too many login attempts, please try again later.');
const generalLimiter = createRateLimiter(60 * 1000, 100, 'Too many requests from this IP, please try again later.');
const strictLimiter = createRateLimiter(60 * 1000, 10, 'Too many requests, please slow down.');

module.exports = {
  authLimiter,
  generalLimiter,
  strictLimiter
};