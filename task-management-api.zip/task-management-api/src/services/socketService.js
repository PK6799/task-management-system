// src/services/socketService.js
const socketIO = require('socket.io');

let io;

const initializeSocket = (server) => {
  io = socketIO(server, {
    cors: {
      origin: process.env.CLIENT_URL || "http://localhost:3000",
      methods: ["GET", "POST"]
    }
  });

  io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    // Join user to their room for private updates
    socket.on('join_user', (userId) => {
      socket.join(`user_${userId}`);
    });

    // Join team room for team updates
    socket.on('join_team', (teamId) => {
      socket.join(`team_${teamId}`);
    });

    socket.on('disconnect', () => {
      console.log('User disconnected:', socket.id);
    });
  });

  return io;
};

const emitTaskUpdate = (event, task) => {
  if (io) {
    // Emit to the assigned user
    io.to(`user_${task.assignedTo._id || task.assignedTo}`).emit(event, task);
    
    // Emit to the creator
    io.to(`user_${task.createdBy._id || task.createdBy}`).emit(event, task);
    
    // Emit to team room if applicable
    // This would require additional logic to determine the team
  }
};

module.exports = {
  initializeSocket,
  emitTaskUpdate,
  getIO: () => io
};