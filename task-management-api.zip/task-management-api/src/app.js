const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// In-memory data storage (temporary)
let users = [];
let tasks = [];
let nextUserId = 1;
let nextTaskId = 1;

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    success: true,
    message: 'Server is running! 🚀',
    timestamp: new Date().toISOString()
  });
});

// Test endpoint
app.get('/api/test', (req, res) => {
  res.json({
    success: true,
    message: 'API is working perfectly! ✅',
    data: {
      users_count: users.length,
      tasks_count: tasks.length
    }
  });
});

// Simple user registration
app.post('/api/auth/register', (req, res) => {
  try {
    const { username, email, password } = req.body;
    
    // Simple validation
    if (!username || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide username, email and password'
      });
    }
    
    // Check if user already exists
    const existingUser = users.find(user => user.email === email);
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'User already exists with this email'
      });
    }
    
    // Create new user
    const newUser = {
      id: nextUserId++,
      username,
      email,
      password: 'encrypted_in_real_app', // We'll encrypt later
      roles: ['user'],
      createdAt: new Date()
    };
    
    users.push(newUser);
    
    res.status(201).json({
      success: true,
      message: 'User registered successfully!',
      data: {
        user: {
          id: newUser.id,
          username: newUser.username,
          email: newUser.email,
          roles: newUser.roles
        }
      }
    });
    
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
});

// Simple user login
app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Simple validation
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email and password'
      });
    }
    
    // Find user
    const user = users.find(u => u.email === email);
    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }
    
    // Simple password check (in real app, we would verify properly)
    if (password.length < 6) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password'
      });
    }
    
    res.json({
      success: true,
      message: 'Login successful!',
      data: {
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          roles: user.roles
        },
        token: 'fake_jwt_token_for_now' // We'll add real JWT later
      }
    });
    
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
});

// Get all users (for testing)
app.get('/api/users', (req, res) => {
  res.json({
    success: true,
    data: {
      users: users.map(user => ({
        id: user.id,
        username: user.username,
        email: user.email,
        roles: user.roles,
        createdAt: user.createdAt
      }))
    }
  });
});

// Create a task
app.post('/api/tasks', (req, res) => {
  try {
    const { title, description, dueDate, priority } = req.body;
    
    // Simple validation
    if (!title) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a title for the task'
      });
    }
    
    const newTask = {
      id: nextTaskId++,
      title,
      description: description || '',
      dueDate: dueDate || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // Default: 1 week from now
      priority: priority || 'medium',
      status: 'pending',
      assignedTo: 1, // Assign to first user for now
      createdBy: 1,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    tasks.push(newTask);
    
    res.status(201).json({
      success: true,
      message: 'Task created successfully!',
      data: {
        task: newTask
      }
    });
    
  } catch (error) {
    console.error('Create task error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
});

// Get all tasks
app.get('/api/tasks', (req, res) => {
  res.json({
    success: true,
    data: {
      tasks: tasks
    }
  });
});

// Get task by ID
app.get('/api/tasks/:id', (req, res) => {
  try {
    const taskId = parseInt(req.params.id);
    const task = tasks.find(t => t.id === taskId);
    
    if (!task) {
      return res.status(404).json({
        success: false,
        message: 'Task not found'
      });
    }
    
    res.json({
      success: true,
      data: {
        task: task
      }
    });
    
  } catch (error) {
    console.error('Get task error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
});

// Update a task
app.put('/api/tasks/:id', (req, res) => {
  try {
    const taskId = parseInt(req.params.id);
    const taskIndex = tasks.findIndex(t => t.id === taskId);
    
    console.log('📝 Update task request - ID:', taskId, 'Data:', req.body);
    
    if (taskIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Task not found'
      });
    }
    
    const updatedTask = {
      ...tasks[taskIndex],
      ...req.body,
      updatedAt: new Date()
    };
    
    tasks[taskIndex] = updatedTask;
    
    console.log('✅ Task updated successfully:', updatedTask);
    
    res.json({
      success: true,
      message: 'Task updated successfully!',
      data: {
        task: updatedTask
      }
    });
    
  } catch (error) {
    console.error('Update task error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during task update'
    });
  }
});

// Delete a task
app.delete('/api/tasks/:id', (req, res) => {
  try {
    const taskId = parseInt(req.params.id);
    const taskIndex = tasks.findIndex(t => t.id === taskId);
    
    if (taskIndex === -1) {
      return res.status(404).json({
        success: false,
        message: 'Task not found'
      });
    }
    
    tasks.splice(taskIndex, 1);
    
    res.json({
      success: true,
      message: 'Task deleted successfully!'
    });
    
  } catch (error) {
    console.error('Delete task error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({
    success: false,
    message: 'Something went wrong!'
  });
});

// 404 handler - FIXED THIS LINE!
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Route not found: ' + req.originalUrl
  });
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`🎉 Server is running on port ${PORT}`);
  console.log(`📍 Health check: http://localhost:${PORT}/health`);
  console.log(`📍 API Test: http://localhost:${PORT}/api/test`);
  console.log(`📍 Users: http://localhost:${PORT}/api/users`);
  console.log(`📍 Tasks: http://localhost:${PORT}/api/tasks`);
  console.log('');
  console.log('✅ Simple Task Manager API Ready!');
  console.log('📝 You can now test the basic endpoints');
  console.log('');
  console.log('🚀 Available Endpoints:');
  console.log('   POST /api/auth/register - Register user');
  console.log('   POST /api/auth/login    - Login user');
  console.log('   GET  /api/users         - Get all users');
  console.log('   POST /api/tasks         - Create task');
  console.log('   GET  /api/tasks         - Get all tasks');
  console.log('   GET  /api/tasks/:id     - Get task by ID');
  console.log('   PUT  /api/tasks/:id     - Update task');
  console.log('   DELETE /api/tasks/:id   - Delete task');
});