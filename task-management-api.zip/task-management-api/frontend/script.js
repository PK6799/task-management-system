// API Configuration - FIXED PORT
const API_BASE = 'http://localhost:3000/api';

// State Management
let currentUser = null;
let tasks = [];

// DOM Elements
const elements = {
    loadingScreen: document.getElementById('loadingScreen'),
    authSection: document.getElementById('authSection'),
    appSection: document.getElementById('appSection'),
    loginForm: document.getElementById('loginForm'),
    registerForm: document.getElementById('registerForm'),
    tabBtns: document.querySelectorAll('.tab-btn'),
    contentSections: document.querySelectorAll('.content-section'),
    navItems: document.querySelectorAll('.nav-item'),
    userName: document.getElementById('userName'),
    dropdownUserName: document.getElementById('dropdownUserName'),
    dropdownUserEmail: document.getElementById('dropdownUserEmail'),
    tasksList: document.getElementById('tasksList'),
    recentTasksList: document.getElementById('recentTasksList'),
    createTaskForm: document.getElementById('createTaskForm'),
    pendingCount: document.getElementById('pendingCount'),
    progressCount: document.getElementById('progressCount'),
    completedCount: document.getElementById('completedCount'),
    totalCount: document.getElementById('totalCount'),
    tasksCount: document.getElementById('tasksCount'),
    highCount: document.getElementById('highCount'),
    mediumCount: document.getElementById('mediumCount'),
    lowCount: document.getElementById('lowCount')
};

// Utility Functions
class Utils {
    static showLoading() {
        elements.loadingScreen.classList.remove('hidden');
    }

    static hideLoading() {
        elements.loadingScreen.classList.add('hidden');
    }

    static showToast(title, message, type = 'success') {
        const toastContainer = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'exclamation-triangle' : 'info-circle'}"></i>
            <div class="toast-content">
                <div class="toast-title">${title}</div>
                <div class="toast-message">${message}</div>
            </div>
        `;
        
        toastContainer.appendChild(toast);
        
        setTimeout(() => {
            toast.remove();
        }, 5000);
    }

    static formatDate(dateString) {
        if (!dateString) return 'No date';
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'short',
                day: 'numeric'
            });
        } catch {
            return 'Invalid date';
        }
    }

    static getPriorityColor(priority) {
        const colors = {
            high: '#ef4444',
            medium: '#f59e0b',
            low: '#10b981'
        };
        return colors[priority] || '#6366f1';
    }

    static getStatusColor(status) {
        const colors = {
            pending: '#f59e0b',
            'in-progress': '#6366f1',
            completed: '#10b981',
            cancelled: '#ef4444'
        };
        return colors[status] || '#64748b';
    }
}

// API Service
class APIService {
    static async request(endpoint, options = {}) {
        const url = `${API_BASE}${endpoint}`;
        
        console.log('🌐 API Request:', url, options);
        
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        };

        if (config.body) {
            config.body = JSON.stringify(config.body);
        }

        try {
            const response = await fetch(url, config);
            const data = await response.json();
            
            console.log('📡 API Response:', data);
            
            if (!response.ok) {
                throw new Error(data.message || `HTTP ${response.status}: ${response.statusText}`);
            }
            
            return data;
        } catch (error) {
            console.error('❌ API Error:', error);
            throw error;
        }
    }

    static async register(userData) {
        return this.request('/auth/register', {
            method: 'POST',
            body: userData
        });
    }

    static async login(credentials) {
        return this.request('/auth/login', {
            method: 'POST',
            body: credentials
        });
    }

    static async getTasks() {
        return this.request('/tasks');
    }

    static async createTask(taskData) {
        return this.request('/tasks', {
            method: 'POST',
            body: taskData
        });
    }

    static async updateTask(taskId, updates) {
        return this.request(`/tasks/${taskId}`, {
            method: 'PUT',
            body: updates
        });
    }

    static async deleteTask(taskId) {
        return this.request(`/tasks/${taskId}`, {
            method: 'DELETE'
        });
    }

    static async getUsers() {
        return this.request('/users');
    }
}

// Auth Management
class AuthManager {
    static async handleLogin(credentials) {
        try {
            Utils.showLoading();
            console.log('🔐 Attempting login:', credentials);
            
            const response = await APIService.login(credentials);
            
            currentUser = response.data.user;
            this.setUserInfo(currentUser);
            this.showApp();
            
            Utils.showToast('Welcome back!', `Hello ${currentUser.username}`, 'success');
            await TaskManager.loadTasks();
            
        } catch (error) {
            console.error('Login error:', error);
            Utils.showToast('Login Failed', error.message, 'error');
        } finally {
            Utils.hideLoading();
        }
    }

    static async handleRegister(userData) {
        try {
            Utils.showLoading();
            console.log('👤 Attempting registration:', userData);
            
            const response = await APIService.register(userData);
            
            Utils.showToast('Account Created!', 'You can now login with your credentials', 'success');
            
            // Auto-fill login form after registration
            document.getElementById('loginEmail').value = userData.email;
            document.getElementById('loginPassword').value = userData.password;
            
            this.switchToLogin();
            
        } catch (error) {
            console.error('Registration error:', error);
            Utils.showToast('Registration Failed', error.message, 'error');
        } finally {
            Utils.hideLoading();
        }
    }

    static setUserInfo(user) {
        elements.userName.textContent = user.username;
        elements.dropdownUserName.textContent = user.username;
        elements.dropdownUserEmail.textContent = user.email;
    }

    static showApp() {
        elements.authSection.classList.add('hidden');
        elements.appSection.classList.remove('hidden');
        elements.appSection.classList.add('fade-in');
    }

    static switchToLogin() {
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.auth-form').forEach(form => form.classList.remove('active'));
        
        document.querySelector('[data-tab="login"]').classList.add('active');
        elements.loginForm.classList.add('active');
    }

    static logout() {
        currentUser = null;
        tasks = [];
        
        elements.appSection.classList.add('hidden');
        elements.authSection.classList.remove('hidden');
        elements.authSection.classList.add('fade-in');
        
        elements.loginForm.reset();
        this.switchToLogin();
        
        Utils.showToast('Logged out', 'You have been successfully logged out', 'success');
    }
}

// Task Management
class TaskManager {
    static async loadTasks() {
        try {
            const response = await APIService.getTasks();
            tasks = response.data.tasks || [];
            this.renderTasks();
            this.updateStats();
            this.updateAnalytics();
        } catch (error) {
            console.error('Load tasks error:', error);
            Utils.showToast('Error', 'Failed to load tasks', 'error');
        }
    }

    static renderTasks() {
        // Render all tasks
        elements.tasksList.innerHTML = tasks.length > 0 
            ? tasks.map(task => this.createTaskHTML(task)).join('')
            : '<div class="no-tasks">No tasks found. Create your first task!</div>';
        
        // Render recent tasks (last 5)
        const recentTasks = tasks.slice(-5).reverse();
        elements.recentTasksList.innerHTML = recentTasks.length > 0
            ? recentTasks.map(task => this.createTaskHTML(task)).join('')
            : '<div class="no-tasks">No recent tasks</div>';
        
        // Update tasks count badge
        elements.tasksCount.textContent = tasks.length;
    }

static createTaskHTML(task) {
    const dueDate = task.dueDate ? Utils.formatDate(task.dueDate) : 'No due date';
    const priorityClass = task.priority || 'medium';
    
    return `
        <div class="task-item ${priorityClass}" data-task-id="${task.id}">
            <div class="task-header">
                <div class="task-info">
                    <div class="task-title">${task.title || 'Untitled Task'}</div>
                    ${task.description ? `<div class="task-description">${task.description}</div>` : ''}
                </div>
                <div class="task-status">
                    <span class="status-badge" style="background: ${Utils.getStatusColor(task.status)}; color: white; padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: 500;">
                        ${task.status || 'pending'}
                    </span>
                </div>
            </div>
            <div class="task-meta">
                <div class="task-meta-item">
                    <i class="fas fa-flag" style="color: ${Utils.getPriorityColor(task.priority)}"></i>
                    ${task.priority || 'medium'} priority
                </div>
                <div class="task-meta-item">
                    <i class="fas fa-calendar"></i>
                    ${dueDate}
                </div>
                <div class="task-meta-item">
                    <i class="fas fa-clock"></i>
                    ${Utils.formatDate(task.createdAt)}
                </div>
            </div>
            <div class="task-actions">
                ${task.status !== 'completed' ? `
                    <button class="task-btn btn-complete" onclick="TaskManager.completeTask(${task.id})">
                        <i class="fas fa-check"></i> Complete
                    </button>
                ` : ''}
                <button class="task-btn btn-edit" onclick="TaskManager.editTask(${task.id})">
                    <i class="fas fa-edit"></i> Edit
                </button>
                <button class="task-btn btn-delete" onclick="TaskManager.deleteTask(${task.id})">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </div>
        </div>
    `;
}

    static async createTask(taskData) {
        try {
            Utils.showLoading();
            await APIService.createTask(taskData);
            await this.loadTasks();
            Utils.showToast('Task Created', 'New task has been added successfully', 'success');
            elements.createTaskForm.reset();
            NavigationManager.showSection('tasks');
        } catch (error) {
            console.error('Create task error:', error);
            Utils.showToast('Error', 'Failed to create task: ' + error.message, 'error');
        } finally {
            Utils.hideLoading();
        }
    }

    static async completeTask(taskId) {
        try {
            await APIService.updateTask(taskId, { status: 'completed' });
            await this.loadTasks();
            Utils.showToast('Task Completed', 'Task marked as completed', 'success');
        } catch (error) {
            console.error('Complete task error:', error);
            Utils.showToast('Error', 'Failed to complete task', 'error');
        }
    }

    static async deleteTask(taskId) {
        if (confirm('Are you sure you want to delete this task?')) {
            try {
                await APIService.deleteTask(taskId);
                await this.loadTasks();
                Utils.showToast('Task Deleted', 'Task has been removed', 'success');
            } catch (error) {
                console.error('Delete task error:', error);
                Utils.showToast('Error', 'Failed to delete task', 'error');
            }
        }
    }

    // Add this to the TaskManager class
static editTask(taskId) {
    const task = tasks.find(t => t.id === taskId);
    if (!task) {
        Utils.showToast('Error', 'Task not found', 'error');
        return;
    }
    
    this.showEditModal(task);
}

static showEditModal(task) {
    // Create modal HTML
    const modalHTML = `
        <div id="editTaskModal" class="modal-overlay">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Edit Task</h3>
                    <button class="modal-close" onclick="TaskManager.closeEditModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <form id="editTaskForm" class="task-form">
                    <input type="hidden" id="editTaskId" value="${task.id}">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="editTaskTitle">Task Title *</label>
                            <input type="text" id="editTaskTitle" value="${task.title || ''}" placeholder="What needs to be done?" required>
                        </div>
                        <div class="form-group">
                            <label for="editTaskPriority">Priority</label>
                            <select id="editTaskPriority">
                                <option value="low" ${task.priority === 'low' ? 'selected' : ''}>Low</option>
                                <option value="medium" ${task.priority === 'medium' ? 'selected' : ''}>Medium</option>
                                <option value="high" ${task.priority === 'high' ? 'selected' : ''}>High</option>
                            </select>
                        </div>
                        <div class="form-group full-width">
                            <label for="editTaskDescription">Description</label>
                            <textarea id="editTaskDescription" placeholder="Add details about this task..." rows="3">${task.description || ''}</textarea>
                        </div>
                        <div class="form-group">
                            <label for="editTaskDueDate">Due Date</label>
                            <input type="date" id="editTaskDueDate" value="${task.dueDate ? task.dueDate.split('T')[0] : ''}">
                        </div>
                        <div class="form-group">
                            <label for="editTaskStatus">Status</label>
                            <select id="editTaskStatus">
                                <option value="pending" ${task.status === 'pending' ? 'selected' : ''}>Pending</option>
                                <option value="in-progress" ${task.status === 'in-progress' ? 'selected' : ''}>In Progress</option>
                                <option value="completed" ${task.status === 'completed' ? 'selected' : ''}>Completed</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="btn-secondary" onclick="TaskManager.closeEditModal()">Cancel</button>
                        <button type="submit" class="btn-primary">
                            <i class="fas fa-save"></i>
                            Update Task
                        </button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    // Add modal to page
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Add event listener for form submission
    document.getElementById('editTaskForm').addEventListener('submit', this.handleEditSubmit.bind(this));
}

static async handleEditSubmit(e) {
    e.preventDefault();
    
    const taskId = parseInt(document.getElementById('editTaskId').value);
    const taskData = {
        title: document.getElementById('editTaskTitle').value,
        description: document.getElementById('editTaskDescription').value,
        priority: document.getElementById('editTaskPriority').value,
        status: document.getElementById('editTaskStatus').value,
        dueDate: document.getElementById('editTaskDueDate').value || undefined
    };
    
    try {
        Utils.showLoading();
        await APIService.updateTask(taskId, taskData);
        await this.loadTasks();
        this.closeEditModal();
        Utils.showToast('Task Updated', 'Task has been updated successfully', 'success');
    } catch (error) {
        console.error('Update task error:', error);
        Utils.showToast('Error', 'Failed to update task: ' + error.message, 'error');
    } finally {
        Utils.hideLoading();
    }
}

static closeEditModal() {
    const modal = document.getElementById('editTaskModal');
    if (modal) {
        modal.remove();
    }
}

    static updateStats() {
        const pending = tasks.filter(t => t.status === 'pending').length;
        const progress = tasks.filter(t => t.status === 'in-progress').length;
        const completed = tasks.filter(t => t.status === 'completed').length;
        const total = tasks.length;

        elements.pendingCount.textContent = pending;
        elements.progressCount.textContent = progress;
        elements.completedCount.textContent = completed;
        elements.totalCount.textContent = total;
    }

    static updateAnalytics() {
        const high = tasks.filter(t => t.priority === 'high').length;
        const medium = tasks.filter(t => t.priority === 'medium').length;
        const low = tasks.filter(t => t.priority === 'low').length;

        elements.highCount.textContent = high;
        elements.mediumCount.textContent = medium;
        elements.lowCount.textContent = low;

        this.updateCharts();
    }

    static updateCharts() {
        const pending = tasks.filter(t => t.status === 'pending').length;
        const progress = tasks.filter(t => t.status === 'in-progress').length;
        const completed = tasks.filter(t => t.status === 'completed').length;
        const total = tasks.length;

        const pendingPercent = total > 0 ? (pending / total) * 100 : 0;
        const progressPercent = total > 0 ? (progress / total) * 100 : 0;
        const completedPercent = total > 0 ? (completed / total) * 100 : 0;

        const bars = document.querySelectorAll('.chart-bar');
        if (bars[0]) bars[0].style.height = `${Math.max(pendingPercent, 10)}%`;
        if (bars[1]) bars[1].style.height = `${Math.max(progressPercent, 10)}%`;
        if (bars[2]) bars[2].style.height = `${Math.max(completedPercent, 10)}%`;
    }
}

// Navigation Management
class NavigationManager {
    static showSection(sectionName) {
        elements.contentSections.forEach(section => section.classList.remove('active'));
        elements.navItems.forEach(item => item.classList.remove('active'));
        
        document.getElementById(`${sectionName}Section`).classList.add('active');
        document.querySelector(`[data-section="${sectionName}"]`).classList.add('active');
    }

    static initNavigation() {
        elements.navItems.forEach(item => {
            item.addEventListener('click', () => {
                const section = item.dataset.section;
                this.showSection(section);
            });
        });
    }
}

// Event Listeners
class EventManager {
    static init() {
        this.initAuthEvents();
        this.initTaskEvents();
        this.initNavigationEvents();
        this.initUIEvents();
    }

    static initAuthEvents() {
        elements.tabBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const tab = btn.dataset.tab;
                
                elements.tabBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                
                document.querySelectorAll('.auth-form').forEach(form => form.classList.remove('active'));
                document.getElementById(`${tab}Form`).classList.add('active');
            });
        });

        elements.loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const credentials = {
                email: document.getElementById('loginEmail').value,
                password: document.getElementById('loginPassword').value
            };
            await AuthManager.handleLogin(credentials);
        });

        elements.registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const userData = {
                username: document.getElementById('registerUsername').value,
                email: document.getElementById('registerEmail').value,
                password: document.getElementById('registerPassword').value
            };
            await AuthManager.handleRegister(userData);
        });

        document.querySelectorAll('.toggle-password').forEach(btn => {
            btn.addEventListener('click', () => {
                const input = btn.parentElement.querySelector('input');
                const icon = btn.querySelector('i');
                
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.className = 'fas fa-eye-slash';
                } else {
                    input.type = 'password';
                    icon.className = 'fas fa-eye';
                }
            });
        });
    }

    static initTaskEvents() {
        elements.createTaskForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const taskData = {
                title: document.getElementById('taskTitle').value,
                description: document.getElementById('taskDescription').value,
                priority: document.getElementById('taskPriority').value,
                status: document.getElementById('taskStatus').value,
                dueDate: document.getElementById('taskDueDate').value || undefined
            };
            
            await TaskManager.createTask(taskData);
        });

        document.getElementById('cancelCreate').addEventListener('click', () => {
            elements.createTaskForm.reset();
            NavigationManager.showSection('tasks');
        });

        document.getElementById('refreshTasks').addEventListener('click', () => {
            TaskManager.loadTasks();
        });

        document.getElementById('statusFilter').addEventListener('change', this.filterTasks);
        document.getElementById('priorityFilter').addEventListener('change', this.filterTasks);
    }

    static filterTasks() {
        const statusFilter = document.getElementById('statusFilter').value;
        const priorityFilter = document.getElementById('priorityFilter').value;
        
        const filteredTasks = tasks.filter(task => {
            const statusMatch = statusFilter === 'all' || task.status === statusFilter;
            const priorityMatch = priorityFilter === 'all' || task.priority === priorityFilter;
            return statusMatch && priorityMatch;
        });
        
        elements.tasksList.innerHTML = filteredTasks.length > 0
            ? filteredTasks.map(task => TaskManager.createTaskHTML(task)).join('')
            : '<div class="no-tasks">No tasks match your filters</div>';
    }

    static initNavigationEvents() {
        NavigationManager.initNavigation();
    }

    static initUIEvents() {
        document.getElementById('logoutBtn').addEventListener('click', () => {
            AuthManager.logout();
        });

        // Set default due date to tomorrow
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        document.getElementById('taskDueDate').min = tomorrow.toISOString().split('T')[0];
        document.getElementById('taskDueDate').value = tomorrow.toISOString().split('T')[0];
    }
}

// Initialize App
class App {
    static init() {
        // Add some CSS for no-tasks message
        const style = document.createElement('style');
        style.textContent = `
            .no-tasks {
                text-align: center;
                padding: 40px;
                color: #94a3b8;
                font-style: italic;
            }
        `;
        document.head.appendChild(style);

        Utils.hideLoading();
        EventManager.init();
        
        console.log('🚀 TaskFlow App Initialized');
        console.log('📍 Backend URL:', API_BASE);
    }
}

// Start the app
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});